export default class Sk1 {
    constructor() {
        this.skinName = "狮心王";
        this.skin = "./sources/skins/301662.png";
        this.ico="./sources/heros/yase3.png";
    }
}