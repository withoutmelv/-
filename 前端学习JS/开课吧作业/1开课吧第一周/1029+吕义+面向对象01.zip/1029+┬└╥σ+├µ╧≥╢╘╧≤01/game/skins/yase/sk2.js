export default class Sk1 {
    constructor() {
        this.skinName = "死亡骑士";
        this.skin = "./sources/skins/301661.png";
        this.ico="./sources/heros/yase2.png";
    }
}