export default class Sk1 {
    constructor() {
        this.skinName = "圣骑之力";
        this.skin = "./sources/skins/301660.png";
        this.ico="./sources/heros/yase1.png";
    }
}