export default class Sk1 {
    constructor() {
        this.skinName = "福禄兄弟";
        this.skin = "./sources/skins/301122.png";
        this.ico="./sources/heros/luban3.png";
    }
}