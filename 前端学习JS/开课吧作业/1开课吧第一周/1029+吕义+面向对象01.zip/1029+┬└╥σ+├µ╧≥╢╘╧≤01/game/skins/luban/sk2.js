export default class Sk1 {
    constructor() {
        this.skinName = "木偶奇遇记";
        this.skin = "./sources/skins/301121.png";
        this.ico="./sources/heros/luban2.png";
    }
}