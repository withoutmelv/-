export default class Sk1 {
    constructor() {
        this.skinName = "机关造物";
        this.skin = "./sources/skins/301120.png";
        this.ico="./sources/heros/luban1.png";
    }
}