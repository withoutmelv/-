export default class S1{
    constructor(){
        this.name = "技能一";
        this.ico = "./sources/skills/11210.png";
    }
}