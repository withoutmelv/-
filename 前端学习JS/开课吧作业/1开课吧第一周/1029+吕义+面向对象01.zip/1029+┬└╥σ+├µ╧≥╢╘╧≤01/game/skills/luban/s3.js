export default class S1{
    constructor(){
        this.name = "技能三";
        this.ico = "./sources/skills/11230.png";
    }
}