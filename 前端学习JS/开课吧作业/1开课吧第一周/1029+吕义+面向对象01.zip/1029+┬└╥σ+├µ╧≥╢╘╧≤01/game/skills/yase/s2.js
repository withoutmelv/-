export default class S2{
    constructor(){
        this.name = "技能二";
        this.ico = "./sources/skills/16620.png";
    }
}