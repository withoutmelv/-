import S1 from '../skills/luban/s1.js';
import S2 from '../skills/luban/s2.js';
import S3 from '../skills/luban/s3.js';
import Sk1 from '../skins/luban/sk1.js';
import Sk2 from '../skins/luban/sk2.js';
import Sk3 from '../skins/luban/sk3.js';

export default class Luban {
    constructor() {
        this.name = "鲁班";
        this.ico = "./sources/heros/luban1.png";
        this.normalSkin="./sources/skins/301120.png";
        this.skins = [new Sk1(),new Sk2(),new Sk3()];
        this.skills = [new S1(), new S2(), new S3()];
    }
}


// 多个玩家 ---》多个亚瑟（有鲁班没有的特性）  多个鲁班（有其他英雄没有的特性） ---》hero （所有英雄的共性）;