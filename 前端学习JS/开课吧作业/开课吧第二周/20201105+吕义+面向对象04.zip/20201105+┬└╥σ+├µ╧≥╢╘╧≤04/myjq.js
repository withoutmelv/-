

class Jq {
    constructor(args,root) {
        // 上次操作节点；root
        if(typeof root === "undefined"){
            this['prevObj'] = [document];
        }else{
            this['prevObj'] = root;
        }
        // 获取元素
        // this.ele = document.querySelector(args);
        // this.elels = document.querySelectorAll(args);
        // this[0] = ele1 this[1] = ele2 
        // let eles = document.querySelectorAll(args);
        // this.addEles(eles);
        // console.log(this);

        if (typeof args === "string") {
            // $(".box1")
            let eles = document.querySelectorAll(args);
            this.addEles(eles);
        } else if (typeof args === "function") {
            // $(function(){
            //     console.log("ready");
            // })
            document.addEventListener("DOMContentLoaded",args);

        } else {
            // $(document.querySelector(".box1")).
            if(typeof args.length === "undefined"){
                // 对象
                this[0] = args;
                this.length = 1;
            }else{
                // 数组；
                this.addEles(args);
            }
        }   

    }
    addEles(eles) {
        for (let i = 0; i < eles.length; i++) {
            this[i] = eles[i];
        }
        this.length = eles.length;
    }
    click(cb) {
        // 绑定事件；
        // this.ele.addEventListener("click",cb);
        for (let i = 0; i < this.length; i++) {
            this[i].addEventListener("click", cb);
        }
    }
    on(eventName, cb) {
        // console.log("on..")
        // 多个元素  多个事件处理
        let eventNameArr = eventName.split(" ");
        for (let i = 0; i < this.length; i++) {
            for (let j = 0; j < eventNameArr.length; j++) {
                // console.log(this[i]);
                this[i].addEventListener(eventNameArr[j], cb);
            }
        }
    }   
    eq(index){
        // console.log(new Jq(this[index]));
        // 原生js对象；返还jq对象；
        // return this[index];
        // return this; (box1,box2)
        return new Jq(this[index],this);  // (一个元素 box2)
        // 1.返还this； 2. 返还新的实例化对象；
    }
    end(){
        return this['prevObj'];
    }
    css(...args){
        if(args.length===1){
            if(typeof args[0] === "string"){
                // 获取样式
              return this.getStyle(this[0],args[0]);
            }else{
                // 对象  多个元素设置 多个样式
                for(let i=0;i<this.length;i++){
                    for(let j in args[0]){
                        this.setStyle(this[i],j,args[0][j]);
                    }
                }
            }
        }else{
            // css("background","yellow");
            // 设置样式；多个元素设置一个样式
            for(let i=0;i<this.length;i++){
                this.setStyle(this[i],args[0],args[1]);
            }
        }
    }

    getStyle(ele,styleName){
        return window.getComputedStyle(ele,null)[styleName];
    }

    setStyle(ele,styleName,styleValue){
        if(typeof styleValue === "number"){
            if(!$.cssNumber[styleName]){
                styleValue = styleValue + "px";
            }
        }
        ele.style[styleName] = styleValue;
    }

    //JQ animate动画
    animate(...args){
        //过滤掉对象中非数字类型的属性
        //像display:'none'等
        let judge=args[0];
        let styleObj={};
        for(let j in judge){
            if(typeof judge[j]==='number'){
                styleObj[j]=judge[j];
            }
        }
        
        //只有一个参数
        if(args.length===1){
            //设置默认动画时间为500ms
            styleObj.duration=500;
            for(let i=0;i<this.length;i++){
                for(let j in styleObj){
                    if(j!=='duration'){
                        this.createAnimation(this[i],styleObj,j);      
                    }
                }
                
            }
            for(let i=0;i<args.length;i++){
                console.log(args[i]);
            }
        }
        //有两个个参数
        else if(args.length===2){
            //设置动画时间
            if(typeof args[1]!=='function'){
                if(args[1]==='linear'||args[1]==='swing'){
                    let easingModel=args[1];
                    styleObj.duration=500;
                    for(let i=0;i<this.length;i++){
                        for(let j in styleObj){
                            if(j!=='duration'){
                                this.createAnimation(this[i],styleObj,j,easingModel);
                            }
                        }
                        
                    }
                    for(let i=0;i<args.length;i++){
                        console.log(args[i]);
                    }
                }else{
                    let duration=args[1];
                    if(typeof duration==='string'){
                        //normal:1000ms,slow:1500ms,fast:500ms 
                        if(duration==='normal'){
                            duration=1000;
                        }else if(duration==='slow'){
                            duration=1500;
                        }else if(duration==='fast'){
                            duration=500;
                        }
                    }
                    styleObj.duration=duration;
                    for(let i=0;i<this.length;i++){
                        for(let j in styleObj){
                            if(j!=='duration'){
                                this.createAnimation(this[i],styleObj,j);
                            }
                        }    
                    }
                    for(let i=0;i<args.length;i++){
                        console.log(args[i]);
                    }
                }
            }else{
                let cb=args[1];
                styleObj.duration=500;
                for(let i=0;i<this.length;i++){
                    for(let j in styleObj){
                        if(j!=='duration'){
                            this.createAnimation(this[i],styleObj,j);
                        }
                    }
                    
                }
                for(let i=0;i<args.length;i++){
                    console.log(args[i]);
                }
               
                window.setTimeout(()=>{
                	cb();
                },styleObj.duration);
                
            }
            
            //
        }
        //有三个参数
        else if(args.length===3) {
            if(typeof args[1]!=='function'&&typeof args[2]==='function'){
                if(args[1]==='linear'||args[1]==='swing'){
                    let easingModel=args[1];
                    let cb=args[2];
                    styleObj.duration=500;
                    for(let i=0;i<this.length;i++){
                        for(let j in styleObj){
                            if(j!=='duration'){
                                this.createAnimation(this[i],styleObj,j,easingModel);
                            }
                        }
                        
                    }
                    for(let i=0;i<args.length;i++){
                        console.log(args[i]);
                    }
                    window.setTimeout(()=>{
	                	cb();
	                },styleObj.duration);
                }else{
                    let duration=args[1];
                    let cb=args[2];
                    if(typeof duration==='string'){
                        //normal:1000ms,slow:1500ms,fast:500ms 
                        if(duration==='normal'){
                            duration=1000;
                        }else if(duration==='slow'){
                            duration=1500;
                        }else if(duration==='fast'){
                            duration=500;
                        }
                    }
                    styleObj.duration=duration;
                    for(let i=0;i<this.length;i++){
                        for(let j in styleObj){
                            if(j!=='duration'){
                                this.createAnimation(this[i],styleObj,j);
                            }
                        }   
                    }
                    for(let i=0;i<args.length;i++){
                        console.log(args[i]);
                    }
                    window.setTimeout(()=>{
	                	cb();
	                },styleObj.duration);
                }
            }else if(typeof args[1]!=='function'&&typeof args[2]==='string'){
                let duration=args[1];
                let easingModel=args[2];
                // console.log(easingModel);
                if(typeof duration==='string'){
                    //normal:1000ms,slow:1500ms,fast:500ms 
                    if(duration==='normal'){
                        duration=1000;
                    }else if(duration==='slow'){
                        duration=1500;
                    }else if(duration==='fast'){
                        duration=500;
                    }
                }
                styleObj.duration=duration;
                for(let i=0;i<this.length;i++){
                    for(let j in styleObj){
                        if(j!=='duration'){
                            this.createAnimation(this[i],styleObj,j,easingModel);
                        }
                    }   
                }
                for(let i=0;i<args.length;i++){
                    console.log(args[i]);
                }
            }
        }
        //参数有四个
        else if(args.length===4){
            let duration=args[1];
            let easingModel=args[2];
            let cb=args[3];
            if(typeof duration==='string'){
                //normal:1000ms,slow:1500ms,fast:500ms 
                if(duration==='normal'){
                    duration=1000;
                }else if(duration==='slow'){
                    duration=1500;
                }else if(duration==='fast'){
                    duration=500;
                }
            }
            styleObj.duration=duration;
            for(let i=0;i<this.length;i++){
                for(let j in styleObj){
                    if(j!=='duration'){
                        this.createAnimation(this[i],styleObj,j,easingModel);
                    }
                }   
            }
            for(let i=0;i<args.length;i++){
                console.log(args[i]);
            }
            window.setTimeout(()=>{
                cb();
            },styleObj.duration);
        }
    }

    createAnimation(ele,opts,styleName,easingModel='swing'){
        // console.log(easingModel);
        var timer=null;
        // var Model=0;
        //处理单位，将'100px'==100
        var startStyle=parseFloat(window.getComputedStyle(ele)[styleName]);
        var endStyle=parseFloat(opts[styleName]);
        
        function createTime(){
            return Date.now();
        }

        var startTime=createTime();

        function runAnimation(){
            // Model=Model===0?1:0;

            //计算当前时间，获取当前时间的动画样式nowStyle
            var remainTime=Math.max(0,startTime+opts.duration-createTime());
            var percent=1-remainTime/opts.duration;
            if(easingModel==='swing'){
            	var nowStyle=(endStyle-startStyle)*percent*Math.abs(Math.sin(Math.PI*percent/2))+startStyle;
            }else{
            	var nowStyle=(endStyle-startStyle)*percent+startStyle;
            }
            

            //percent等于1代表动画执行完毕
            if(percent===1){
                clearInterval(timer)
                timer=null;
            }
            // console.log(ele,styleName,nowStyle)
            //设置样式
            setAnimationStyle(ele,styleName,nowStyle);

            // if(percent!==1&&easingModel==='swing'){
            //     clearInterval(timer);
            //     timer=setInterval(runAnimation,2.5+2.5*Model)
            // }
        }

        function setAnimationStyle(ele,styleName,nowStyle){
        	//给数字加上单位
            if(typeof nowStyle === "number"){
                if($.animationNumber[styleName]){
                    nowStyle = nowStyle + "px";
                }
            }
            //处理fontSize==font-size的情况
            var reg=RegExp(/[A-Z]/g);
            var index=styleName.search(reg);
            if(index!==-1){
                styleName=styleName.toLowerCase();
                styleName=styleName.slice(0,index)+'-'+styleName.slice(index);
            }

            ele.style[styleName] = nowStyle;
        }
        //每5ms调用一次runAnimation方法,调节帧数
        timer=setInterval(runAnimation,5);
    }

    
}


function $(args) {
    // return {
    //     click(cb){
    //         console.log("执行了click方法 ");
    //         document.querySelector(args).addEventListener("click",cb);
    //     }
    // }
    return new Jq(args);
}

$.cssNumber = {
    animationIterationCount: true,
    columnCount: true,
    fillOpacity: true,
    flexGrow: true,
    flexShrink: true,
    fontWeight: true,
    gridArea: true,
    gridColumn: true,
    gridColumnEnd: true,
    gridColumnStart: true,
    gridRow: true,
    gridRowEnd: true,
    gridRowStart: true,
    lineHeight: true,
    opacity: true,
    order: true,
    orphans: true,
    widows: true,
    zIndex: true,
    zoom: true
}

$.animationNumber={
    backgroundPosition:true,
    borderWidth:true,
    borderBottomWidth:true,
    borderLeftWidth:true,
    borderRightWidth:true,
    borderTopWidth:true,
    borderSpacing:true,
    margin:true,
    marginBottom:true,
    marginLeft:true,
    marginRight:true,
    marginTop:true,
    outlineWidth:true,
    padding:true,
    paddingBottom:true,
    paddingLeft:true,
    paddingRight:true,
    paddingTop:true,
    height:true,
    width:true,
    maxHeight:true,
    maxWidth:true,
    minHeight:true,
    minWidth:true,
    font:true,
    fontSize:true,
    bottom:true,
    left:true,
    right:true,
    top:true,
    letterSpacing:true,
    wordSpacing:true,
    lineHeight:true,
    textIndent:true
}

// export default $ ;